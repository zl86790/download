package name.lizhe.bo;

public class BusinessBean {
	public void whoami(){
		System.out.println(this);
	}
}
