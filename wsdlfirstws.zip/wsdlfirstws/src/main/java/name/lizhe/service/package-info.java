@javax.xml.bind.annotation.XmlSchema(namespace = "http://service.lizhe.name/")
package name.lizhe.service;
